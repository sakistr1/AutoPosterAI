from .user import User
from .product import Product
from .post import Post
from .template import Template  # <-- ����
