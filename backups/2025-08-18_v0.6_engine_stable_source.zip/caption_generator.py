# caption_generator.py

def generate_caption(title, description, price):
    return f"🌟 Νέο προϊόν: {title} μόνο με {price}!\n📦 {description}\n👇 Δες περισσότερα στο κατάστημά μας!"
